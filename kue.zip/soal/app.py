from flask import Flask, render_template, request, make_response

app = Flask(__name__)

flag = "LKS{c0ok13_bvK4n_t3mP4t_4mAn_unTvk_m3ny1mp4N_1Nf0rM4s1_beRh4rg4}"

@app.route("/")
def index():

    resp = make_response(render_template('index.html'))
    resp.set_cookie('flag', flag)

    return resp