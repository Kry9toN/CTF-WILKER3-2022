from flask import Flask, render_template, request, render_template_string
import urllib.parse

app = Flask(__name__)
app.config['flag'] = "LKS{t3mPl4Te_ju6A_b1SA_di_Svntik}"

@app.route("/")
def index():
    return render_template("pages/index.j2")

@app.route("/search")
def search():
    if request.args.get('q'):
        # return render_template_string(request.args.get('q'))
        return render_template_string("""
        {% extends 'layout.html.j2' %}
        {% block content %}
        <div class="row tm-row">

        <div class="col-12">
            <hr class="tm-hr-primary">
            <h2>Result for: """ + request.args.get('q') +  """</h2>
            <hr class="tm-hr-primary">

        </div>

        <article class="col-12 col-md-6 tm-post">
            <!-- <hr class="tm-hr-primary"> -->
            <a href="post.html" class="effect-lily tm-post-link tm-pt-60">
                <div class="tm-post-link-inner">
                    <img src="{{ url_for('static', filename='img/img-01.jpg') }}" alt="Image" class="img-fluid">                            
                </div>
                <span class="position-absolute tm-new-badge">New</span>
                <h2 class="tm-pt-30 tm-color-primary tm-post-title">Simple and useful HTML layout</h2>
            </a>                    
            <p class="tm-pt-30">
                There is a clickable image with beautiful hover effect and active title link for each post item. 
                Left side is a sticky menu bar. Right side is a blog content that will scroll up and down.
            </p>
            <div class="d-flex justify-content-between tm-pt-45">
                <span class="tm-color-primary">Travel . Events</span>
                <span class="tm-color-primary">June 24, 2020</span>
            </div>
            <hr>
            <div class="d-flex justify-content-between">
                <span>36 comments</span>
                <span>by Admin Nat</span>
            </div>
        </article>

        </div>
        {% endblock %}
        """)
    else:
        return "Bienvenue!"
